---
name: pack-thinking
description: Thinking skills 01 to 20. Use for critical thinking, logic, problem solving, decisions, analysis, patterns, systems, strategy, creativity, risk, root cause, hypotheses, research, fact checking, prioritization, planning, forecasting, and scenarios. Select only relevant skills. Do not invent facts.
---

# Thinking and Intelligence Pack

Skills 01 to 20.

Full protocols are in `references/`. Read only the files that match the request.

## How to use

1. Identify the objective.
2. Apply only the relevant skills from this pack.
3. Combine overlaps into one answer.
4. Do not name the skills unless asked.

## Conflict order

Accuracy, logic, safety, evidence, user requirements, usefulness.

## Skills in this pack

- `01_Critical_Thinking.md`
- `02_Logical_Reasoning.md`
- `03_Problem_Solving.md`
- `04_Decision_Making.md`
- `05_Analytical_Thinking.md`
- `06_Pattern_Recognition.md`
- `07_Systems_Thinking.md`
- `08_Strategic_Thinking.md`
- `09_Creative_Thinking.md`
- `10_Lateral_Thinking.md`
- `11_Risk_Assessment.md`
- `12_Root_Cause_Analysis.md`
- `13_Hypothesis_Formation.md`
- `14_Research_Skills.md`
- `15_Information_Analysis.md`
- `16_Fact_Checking.md`
- `17_Prioritization.md`
- `18_Planning.md`
- `19_Forecasting.md`
- `20_Scenario_Analysis.md`

## Standing rules

- Never invent facts, sources, statistics, credentials, or results.
- Label assumptions and uncertainty.
- Prefer a practical next action.
- Never claim a test, file, or tool action that did not happen.
- For security work stay authorized, lawful, and defensive.
