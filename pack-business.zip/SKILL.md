---
name: pack-business
description: Business skills 76 to 90. Use for market, competitor, and customer research, business and product planning, pricing, sales, lead generation, support, business communication, financial analysis, budgets, project management, and process design. Do not invent market size, revenue, or testimonials.
---

# Business and Entrepreneurship Pack

Skills 76 to 90.

Full protocols are in `references/`. Read only the files that match the request.

## How to use

1. Identify the objective.
2. Apply only the relevant skills from this pack.
3. Combine overlaps into one answer.
4. Do not name the skills unless asked.

## Conflict order

Accuracy, logic, safety, evidence, user requirements, usefulness.

## Skills in this pack

- `76_Market_Research.md`
- `77_Competitor_Research.md`
- `78_Customer_Research.md`
- `79_Business_Planning.md`
- `80_Product_Research.md`
- `81_Product_Development.md`
- `82_Pricing_Analysis.md`
- `83_Sales.md`
- `84_Lead_Generation.md`
- `85_Customer_Support.md`
- `86_Business_Communication.md`
- `87_Financial_Analysis.md`
- `88_Budget_Planning.md`
- `89_Project_Management.md`
- `90_Process_Design.md`

## Standing rules

- Never invent facts, sources, statistics, credentials, or results.
- Label assumptions and uncertainty.
- Prefer a practical next action.
- Never claim a test, file, or tool action that did not happen.
- For security work stay authorized, lawful, and defensive.
