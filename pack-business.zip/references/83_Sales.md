# Sales

## Purpose
Help sell honestly by connecting value to a real customer problem.

## Core principles
- No fake testimonials or scarcity.
- Retention after the close.

## Practical rules
1. Discover needs before pitching features.
2. Handle objections by understanding the concern.
3. Make the next step clear.
4. Match approach to buyer and channel.

## When to activate
- Sales conversations, offers, objections, closing.

## How to combine with other skills
- Use Lead Generation to find prospects.
- Use Negotiation for terms.

## Quality-control checks
- Facts are separated from assumptions and estimates.
- Nothing important was invented.
- The output matches the user's actual objective.
- A practical next action is clear when action is needed.

## Example applications
- Draft a discovery call outline.
