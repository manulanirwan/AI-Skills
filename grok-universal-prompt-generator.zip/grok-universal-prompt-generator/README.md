# Universal Prompt Generator for Grok

A reusable prompt-engineering Skill adapted for Grok environments. It follows the selected settings:

- **Scope:** All domains.
- **Prompt length:** Adaptive to task complexity.
- **Prompt language:** English by default.
- **Interaction:** Hybrid. Generate directly for clear tasks; ask only when important information is missing.

## Package contents

- `SKILL.md` — Grok-compatible Skill instructions and YAML frontmatter.
- `references/prompt-design-patterns.md` — domain-specific prompt structures.
- `references/platform-adaptation.md` — Grok, general AI, coding, media, and research platform guidance.
- `references/quality-checklist-and-tests.md` — quality rubric and test scenarios.
- `references/examples.md` — worked prompt examples.
- `GROK-BOT-SETUP-PROMPT.md` — instructions for saving the same workflow as a Grok Bot skill.

## Installation for Grok Build / Grok CLI (Windows)

This package's native `SKILL.md` format is for Grok Build / Grok CLI skill discovery. It is not a one-click install for the consumer Grok website chat.

1. Extract the ZIP file.
2. Open PowerShell.
3. Create the user-level Grok skills directory if it does not exist:

   ```powershell
   New-Item -ItemType Directory -Force -Path "$HOME\.grok\skills" | Out-Null
   ```

4. Copy the extracted `universal-prompt-generator` folder into `$HOME\.grok\skills\`.

   Or, open PowerShell inside the extracted `grok-universal-prompt-generator` folder and run the included installer:

   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   .\INSTALL-WINDOWS.ps1
   ```

   The installer backs up an existing copy rather than silently overwriting it.
5. The final file path should be:

   ```text
   $HOME\.grok\skills\universal-prompt-generator\SKILL.md
   ```

6. Restart or refresh the Grok Build / CLI session if needed. Check the available skills in its skills interface, then invoke:

   ```text
   /universal-prompt-generator
   ```

   Add your request after the command, or describe the task when prompted.

The official Grok Build documentation lists `~/.grok/skills/` as a user-level discovery path and says user-invocable skills can appear as slash commands. Project-specific skills can instead be placed in `<repo>/.grok/skills/`.

## Save as a Grok Bot skill

Grok Bot has a separate skill workflow. It does not use the Grok Build local `~/.grok/skills/` folder automatically.

1. Open a conversation with the Grok Bot that should use the skill.
2. Attach `SKILL.md` and the Markdown files inside `references/`.
3. Open `GROK-BOT-SETUP-PROMPT.md`, copy its setup instruction, and send it to the Bot.
4. Review the skill the Bot creates. Confirm it retained the workflow, references, and safety boundaries.
5. Enable the private skill for the relevant Bot if the Bot does not see it automatically.

Grok Bot's official documentation describes saving a reusable skill by asking the Bot to save a completed process, and notes that a skill may require connected apps or permissions.

## Consumer Grok chat

The public documentation reviewed for this package does not describe a Claude-style upload-and-install custom Skills manager for ordinary grok.com chats. You can attach or paste the `SKILL.md` content into a conversation for session-level instructions, but do not treat that as a permanently installed Skill. For persistent reuse, use Grok Bot's skill workflow or Grok Build / CLI.

## Test after setup

Try the scenarios in `references/quality-checklist-and-tests.md`, including a simple writing task, a software project, current research, and an authorized cybersecurity assessment.

## Limits

- This package is a set of instructions, not an API connection or an external service.
- It cannot grant the target AI access to tools, files, apps, repositories, or web search.
- Confirm the Skill has actually been discovered and invoked in the target Grok environment before relying on it.
