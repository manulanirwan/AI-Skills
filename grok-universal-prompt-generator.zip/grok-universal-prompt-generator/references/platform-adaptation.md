# Platform Adaptation Guide

## Default rule

When no AI platform is named, create a platform-neutral prompt. Do not add platform-specific syntax, tool names, or capability assumptions.

When a platform is named, adapt only the elements that affect execution. A product name alone does not establish which model, subscription, tools, extensions, runtime, or permissions the user has.

## Grok environments

Treat these as distinct environments:

- **Grok consumer chat (grok.com and mobile apps):** a conversational assistant experience. Do not assume local filesystem, terminal, repository, or persistent Skill-folder access. Do not claim that a Grok Build skill is installed in the consumer chat.
- **Grok Bot:** a bot/work-agent environment with its own skill and routine concepts. A Bot skill should state when it applies, required inputs and access, the work sequence, validation, returned output, failure handling, and any action requiring approval. A skill may need connected apps or permissions to do its work. Do not create a routine unless the user asks for recurring or event-triggered automation.
- **Grok Build / Grok CLI:** an agent environment that discovers reusable skill folders from documented locations such as `~/.grok/skills/` and project-level `.grok/skills/`. Skills use a `SKILL.md` file with YAML frontmatter. User-invocable skills can be available as slash commands. Do not assume this local skill folder is shared with grok.com chat or Grok Bot.

For Grok tasks, verify current capabilities from official xAI documentation when version, feature availability, or setup instructions matter. Do not invent slash commands, file-upload support, settings, or install paths. If the user does not specify which Grok environment they use and it materially changes the instructions, ask one concise clarification. Otherwise, provide a portable prompt and state the environment assumption.

## General chat assistants

For conversational assistants such as ChatGPT, Claude, and Gemini:
- State the goal and context explicitly.
- Specify whether the assistant should answer, ask a clarification, use supplied files, or conduct research.
- Define the output format and desired depth.
- Request citations when factual research is required and sources are available.
- Do not assume browsing, file creation, code execution, connectors, or memory are enabled.

## Coding assistants and IDE agents

For tools such as Cursor, GitHub Copilot, Claude Code, and repository-aware agents:
- Identify the repository, language, framework, runtime, and deployment target when known.
- Inspect the existing project before proposing broad changes.
- Preserve established conventions and avoid unnecessary rewrites.
- Ask for a plan before large or risky edits when this improves control.
- Specify tests and validation commands appropriate to the environment.
- Require a concise report of files changed, behavior added, checks run, and remaining issues.
- Require approval before destructive commands, deployments, purchases, or external publication.

Do not assume an agent can access a repository, terminal, browser, package registry, or Git remote unless the environment provides it.

## Image-generation systems

- State subject, action, setting, intended use, composition, viewpoint, framing, and visual hierarchy as relevant.
- Specify art direction, medium, lighting, palette, aspect ratio, resolution, and transparency only when useful.
- Separate required elements from optional preferences.
- State what must remain unchanged during edits.
- Treat legible text, logos, exact typography, and complex layouts as potential limitations unless the target system is known to support them.
- Do not add a reference image or identity claim the user did not supply or authorize.

## Video and audio generation systems

For video, specify duration, aspect ratio, scene continuity, camera movement, pacing, and audio requirements. Break long sequences into scenes when useful.

For audio, specify voice qualities, language, pace, delivery, sound effects, and output length. Do not request imitation of a living artist's or private person's voice. Use non-identifying vocal descriptions instead.

## Research-oriented systems

For systems with browsing or retrieval:
- State the research question, source hierarchy, recency needs, and citation format.
- Prefer official documentation, primary sources, peer-reviewed research, and direct datasets.
- Require publication dates and distinguish event dates from report dates.
- Ask the system to distinguish verified evidence from interpretation.

Do not assume live web or X search access exists. If unavailable, instruct the model to disclose that limitation rather than invent sources.

## APIs and developer integrations

Identify API, endpoint, model, message roles, input/output schema, and tool definitions only when supplied or verified. Keep system instructions separate from user input and developer instructions where the platform supports those roles. Do not invent model IDs, request fields, headers, or parameters.

## Platform unknown or ambiguous

If a product has multiple materially different environments, ask which one only if it changes the prompt's execution requirements. Otherwise, create a portable prompt and label the assumption.
