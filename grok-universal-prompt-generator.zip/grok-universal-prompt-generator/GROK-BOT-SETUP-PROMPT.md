# Grok Bot Skill Setup Prompt

Use this with a Grok Bot when you want the same prompt-generation workflow saved as a Bot skill.

1. Attach `SKILL.md` and every file in the `references/` folder to the Grok Bot conversation.
2. Paste the following instruction.

---

Read the attached `SKILL.md` and reference files. Create and save a reusable private skill named **Universal Prompt Generator** using the full instructions and reference material.

The skill must:
- Turn rough user requests into precise, copy-ready English prompts.
- Cover technical, cybersecurity, software, AI, business, research, education, writing, marketing, data, productivity, image, video, audio, and creative tasks.
- Adapt prompt length to task complexity.
- Work in hybrid mode: generate immediately for clear requests, and ask only one important clarification when missing information materially affects the result.
- Adapt to the named target AI platform without assuming tools or capabilities that are not available.
- Preserve the user's intent, facts, names, dates, numbers, and constraints.
- Include quality checks, evidence requirements for research, and safe authorization boundaries for cybersecurity and agent workflows.
- Return a complete, copy-ready English prompt by default, with only brief explanation when useful.

Use the attached files as the source of truth. Keep the reference guidance available to the saved skill rather than reducing it to a generic summary. Confirm the saved skill's name and description, explain how I can invoke it, and state any parts you could not preserve.

Do not create a recurring routine or schedule. I asked for a reusable skill only.
