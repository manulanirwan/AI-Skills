# Install Universal Prompt Generator into the current user's Grok Build / CLI skills folder.
# Run this script from the extracted package directory.
$ErrorActionPreference = 'Stop'

$skillName = 'universal-prompt-generator'
$source = Join-Path $PSScriptRoot $skillName
$destinationRoot = Join-Path $HOME '.grok\skills'
$destination = Join-Path $destinationRoot $skillName

if (-not (Test-Path (Join-Path $source 'SKILL.md'))) {
    throw "Could not find '$source\SKILL.md'. Extract the ZIP so the package folder is beside this script."
}

New-Item -ItemType Directory -Force -Path $destinationRoot | Out-Null
if (Test-Path $destination) {
    $backup = "$destination.backup-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
    Move-Item -LiteralPath $destination -Destination $backup
    Write-Output "Existing skill moved to: $backup"
}
Copy-Item -Path $source -Destination $destinationRoot -Recurse -Force
Write-Output "Installed skill at: $destination"
Write-Output 'Restart or refresh your Grok Build / CLI session if needed, then invoke /universal-prompt-generator.'
