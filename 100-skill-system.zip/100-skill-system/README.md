# 100-Skill Operating Library

This package is a portable copy of a 100-skill operating system for thinking, communication, technology, cybersecurity, business, and content work.

## Contents

- `README.md` — this file
- `MASTER_PROMPT.md` — master operating instruction
- `01_Critical_Thinking.md` through `100_Brand_Building.md` — one file per skill

## How to use

1. Read `MASTER_PROMPT.md` first. That file is the selection layer.
2. Open an individual skill file only when you need the full protocol.
3. Do not apply all 100 skills to every request. Select the few that match the job.
4. When skills overlap, combine them into one answer.
5. When skills conflict, prefer factual accuracy, logical consistency, safety, evidence, the user's requirements, then practical usefulness.

## Categories

| Range | Category |
|---|---|
| 01–20 | Thinking and intelligence |
| 21–40 | Communication |
| 41–60 | Technology |
| 61–75 | Cybersecurity (defensive and authorized) |
| 76–90 | Business and entrepreneurship |
| 91–100 | Content and creative |

## Standing limits

- Never invent facts, sources, statistics, credentials, or results.
- Cybersecurity work stays lawful, authorized, and defensive.
- No ranking, view, follower, or revenue guarantees.
- Do not claim work was tested, created, or verified unless it actually was.
