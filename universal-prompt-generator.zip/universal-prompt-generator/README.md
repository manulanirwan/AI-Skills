# Universal Prompt Generator

A custom Agent Skill for turning rough task descriptions and existing prompts into clear, task-specific, copy-ready English prompts.

## Included files

- `SKILL.md` — core workflow and operating rules.
- `references/prompt-design-patterns.md` — domain-specific prompt structures.
- `references/platform-adaptation.md` — platform-aware adaptation guidance.
- `references/quality-checklist-and-tests.md` — review rubric and test scenarios.
- `references/examples.md` — worked examples.

## Install in Claude.ai

1. Enable **Code execution and file creation** (called **Create and edit files** in some settings layouts) under Settings > Capabilities.
2. Open **Customize > Skills**.
3. Choose **+** or **Add**, then **Create skill** > **Upload a skill**.
4. Upload `universal-prompt-generator.zip`.
5. Enable the Skill in the Skills list.
6. Test it using several different requests from `references/quality-checklist-and-tests.md`.

The Skill is designed to produce English prompts by default, adapt prompt length to task complexity, and ask clarifying questions only when important information is missing.

## Notes

- This is a prompt-generation Skill, not an external service or model connection.
- Platform-specific features can change. Verify current capabilities from official documentation when they materially affect the requested prompt.
- Review and test the Skill after uploading. The package itself cannot confirm that Claude has successfully installed or invoked it.
