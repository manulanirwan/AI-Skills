# Platform Adaptation Guide

## Default rule

When no AI platform is named, write a platform-neutral prompt. Do not add platform-specific syntax, tool names, or capability assumptions.

When a platform is named, adapt only the parts that materially affect execution. A platform name alone does not establish which model, plan, tools, extensions, or runtime the user has.

## General chat assistants

For conversational assistants such as Claude, ChatGPT, and Gemini:
- State the goal and context explicitly.
- Specify whether the assistant should answer directly, ask a clarification, use supplied files, or conduct research.
- Define the output format and desired depth.
- Ask for citations when factual research is required and sources are available.
- Avoid API-specific parameters unless the user is working with an API.

Do not assume that browsing, file creation, code execution, connectors, memory, or external integrations are enabled. Phrase these as conditional requirements when availability is unknown.

## Coding assistants and IDE agents

For tools such as Cursor, GitHub Copilot, Claude Code, and other repository-aware coding agents:
- Identify the repository, language, framework, runtime, and deployment target when known.
- Tell the agent to inspect the existing project before proposing broad changes.
- Preserve established conventions and avoid unnecessary rewrites.
- Ask for a plan before large or risky edits when that improves control.
- Specify tests and validation commands appropriate to the project.
- Require a concise report of files changed, behavior added, checks run, and remaining issues.
- Require approval before destructive commands, deployments, purchases, or external publication.

Do not assume IDE agents can access a repository, terminal, browser, package registry, or Git remote unless the environment actually provides it.

## Image-generation systems

For image models and image-generation tools:
- Focus on visible content and composition rather than abstract instructions.
- State aspect ratio, orientation, subject placement, and style when relevant.
- Separate must-have elements from optional preferences.
- State what to preserve during edits and what can change.
- Treat legible text, logos, exact typography, and complex layouts as potential limitations unless the specific tool is known to support them reliably.

Do not add a reference image or identity claim that the user did not supply or authorize.

## Video and audio generation systems

For video tools:
- Specify duration, aspect ratio, scene continuity, camera movement, pacing, and audio requirements.
- Break long sequences into scenes or shots when useful.
- Describe consistent subjects and objects across shots.

For audio tools:
- Specify voice characteristics, language, pace, emotional delivery, sound effects, and output length when relevant.
- Do not request imitation of a living artist's or private person's voice. Offer a non-identifying description of vocal qualities instead.

## Research-oriented systems

For systems with browsing or retrieval:
- State the research question, source hierarchy, recency needs, and citation format.
- Prefer official documentation, primary sources, peer-reviewed research, and direct datasets where relevant.
- Require dates and source links for changing claims.
- Ask the system to distinguish verified evidence from analysis.

Do not assume live web access exists. If it is unavailable, instruct the model to disclose that limitation rather than invent sources.

## APIs and developer integrations

If the user asks for an API-ready prompt or system instruction:
- Identify the API, endpoint or feature, model, message roles, input/output schema, and tool definitions only when supplied or verified.
- Keep system instructions separate from user input and developer instructions where the platform supports these roles.
- Use strict output schemas only when the target supports them.
- Do not invent model IDs, request fields, headers, or parameter names.
- Recommend checking current official documentation when version-specific behavior matters.

## Platform unknown or ambiguous

If a named product has multiple materially different experiences (for example, web chat, desktop app, IDE extension, and API), ask which one only if it changes the prompt's execution requirements. Otherwise, create a portable prompt and label the assumption.
