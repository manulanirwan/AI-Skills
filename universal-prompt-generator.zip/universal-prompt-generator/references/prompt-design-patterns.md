# Prompt Design Patterns

Use these patterns as adaptable structures, not mandatory forms. Include only sections that affect the result.

## Software engineering and application development

Include:
- Product goal, target users, and core user journeys.
- Current repository or project state, supplied files, and existing architecture.
- Exact stack, runtime, dependency, platform, and deployment constraints when known.
- Functional requirements and non-functional requirements.
- UX, accessibility, responsiveness, security, performance, and maintainability requirements as relevant.
- Explicit exclusions and decisions that must not be changed.
- Ordered implementation plan with checkpoints for large tasks.
- Tests, linting, type checks, build checks, and manual acceptance criteria.
- Git or deployment actions and required user approval before destructive or external actions.

Do not invent a stack or repository structure. When essential technical facts are unknown, ask or use clearly marked placeholders. Tell coding agents to inspect existing code before modifying it and to report what they changed and verified. Do not call work complete unless the requested checks were actually run and passed.

## Cybersecurity and IT operations

Keep scope authorized and defensive. Include:
- System, asset, environment, and owner.
- Written authorization and permitted scope.
- Testing window, allowed methods, rate limits, and prohibited actions.
- Defensive objective: assessment, hardening, detection, triage, incident response, secure configuration, or controlled lab learning.
- Evidence handling, logging, privacy, and data minimization.
- Safe validation steps and rollback guidance where relevant.
- Findings ranked by severity with evidence, impact, and remediation.

Do not provide prompts for unauthorized exploitation, persistence, credential theft, stealth, destructive actions, or evasion. Redirect to benign simulations, detection engineering, secure code review, or lab-only demonstrations.

## Research and analysis

Include:
- Research question and decision the research should support.
- Scope, geography, time range, definitions, and exclusions.
- Source hierarchy, prioritizing primary and authoritative sources.
- Requirement to check publication dates and distinguish event dates from reporting dates.
- Evidence table or structured findings where useful.
- Distinction among sourced facts, estimates, interpretation, and unknowns.
- Conflicting evidence and limitations.
- Inline citations or source links for factual claims.

Do not let the target AI invent sources or treat search snippets as full evidence. Require it to state when it cannot verify a claim.

## Business and entrepreneurship

Include:
- Business objective, customer segment, geography, stage, and available resources.
- Customer problem and proposed value.
- Competitors and substitutes.
- Revenue model, costs, margins, capital needs, and key assumptions.
- Regulatory, operational, and market risks.
- Low-cost validation steps and measurable milestones.
- A practical recommendation with assumptions and downside scenarios.

Do not fabricate market size, sales, costs, or customer demand. Label estimates and identify what must be validated locally.

## Marketing, content, and communication

Include:
- Audience, channel, purpose, and desired action.
- Brand voice, tone, message, and required facts.
- Length, format, reading level, and platform constraints.
- Claims that must be avoided or substantiated.
- Variants only when they represent meaningfully different approaches.

For practical writing deliverables, require a ready-to-use draft. Do not add hashtags, emojis, or calls to action unless appropriate or requested.

## Education and learning

Include:
- Learner's current level and target skill.
- Learning objective and measurable outcome.
- Prerequisite knowledge and available time.
- Explanation style, worked examples, exercises, and feedback approach.
- A progression from fundamentals to application.
- A check for understanding and correction of misconceptions.

Do not assume the learner's level if it materially changes the lesson.

## Data analysis and spreadsheets

Include:
- Business question and decisions supported by the analysis.
- Data sources, schema, definitions, units, and date ranges.
- Data quality checks, missing values, duplicates, and assumptions.
- Methods, calculations, and treatment of outliers.
- Expected tables, charts, formulas, or workbook outputs.
- Reproducibility, validation, and limitations.

Do not infer missing values silently or present correlation as causation.

## Image generation and visual design

Include only relevant visual controls:
- Subject, action, setting, and intended use.
- Composition, camera/viewpoint, framing, and focal hierarchy.
- Art direction, medium, texture, lighting, and colour palette.
- Aspect ratio, resolution, transparency, and output constraints.
- Exact text, spelling, and placement if text is required.
- Elements to include and exclude.

Avoid contradictory styles. Do not promise exact rendering of text or fine details when the target image system may not reliably support them. For image editing, state what must remain unchanged and what must change.

## Video, audio, and motion content

Include:
- Purpose, audience, platform, duration, aspect ratio, and format.
- Scene or segment sequence, pacing, transitions, and visual/audio direction.
- Dialogue, narration, sound, music, captions, and language requirements.
- Continuity constraints and elements that must remain consistent.
- Export requirements and accessibility needs.

For generated media, distinguish source assets supplied by the user from assets the model is asked to create.

## AI agents and multi-step workflows

Include:
- Goal and end state.
- Available tools and data sources.
- Tool permissions and actions requiring approval.
- Step boundaries, checkpoints, and stopping conditions.
- Error handling, retries, and recovery behavior.
- Data access restrictions and security boundaries.
- Final evidence report: actions taken, outputs created, checks performed, and unresolved issues.

Do not give an agent unrestricted authority by default. Use least privilege and request confirmation before irreversible, financial, public, or externally visible actions.

## Personal productivity and planning

Include:
- Desired outcome, deadline, constraints, and current commitments.
- Priorities and trade-offs.
- A realistic sequence of actions.
- Required resources and dependencies.
- A simple way to track progress and adjust the plan.

Avoid overengineering small personal tasks.
