# Prompt Examples

These examples show the level of specificity expected. Adapt them to the user's real context rather than copying them mechanically.

## Example A: Rough idea to coding prompt

User request:
"I need a website for my small vehicle brokerage business."

Generated prompt:

```text
Act as an experienced product designer and full-stack software engineer.

Objective
Plan and build a professional website for a small vehicle brokerage business.

Before implementation
1. Ask for the business name, service area, contact methods, preferred technology, and whether listings will be managed manually or through an admin panel.
2. If these details are not provided, identify them as assumptions and do not invent real business information.
3. Inspect the existing project before changing files if a repository is provided.

Core requirements
- Present available vehicles with clear photos, key specifications, price, and listing status.
- Let visitors enquire about a vehicle through the business's approved contact method.
- Include business information, service coverage, and a clear enquiry path.
- Make the site responsive, accessible, fast, and secure.
- Do not publish fake vehicle listings, testimonials, prices, or business credentials.

Deliverables
- Proposed page structure and user flows.
- Recommended implementation plan based on the supplied stack.
- Working implementation if the environment provides project access.
- Tests and a report of what was actually verified.

Do not deploy or publish the site without explicit approval.
```

## Example B: Research prompt

User request:
"Find the best small-business opportunities in Sri Lanka."

Generated prompt:

```text
Act as a market researcher advising an early-stage entrepreneur in Sri Lanka.

Objective
Identify and compare realistic small-business opportunities that can be started with limited capital.

Research requirements
- Use current, dated sources and prioritize official Sri Lankan government, regulatory, industry, and primary business sources.
- State the research date and geographic assumptions.
- Compare customer demand, startup costs, recurring costs, revenue model, competition, regulatory requirements, operational difficulty, and major risks.
- Separate sourced facts from estimates and personal analysis.
- Do not invent market-size figures, income projections, or supplier quotations.

Output
1. A shortlist of opportunities.
2. A comparison table with startup capital bands and key assumptions.
3. The three strongest candidates and why they may fit a small operator.
4. Low-cost validation steps before spending significant money.
5. Risks, unknowns, and sources with publication dates and links.

Do not guarantee profitability. Clearly identify what requires local validation.
```

## Example C: Image-generation prompt

User request:
"Create a clean professional profile image for my technology brand."

Generated prompt:

```text
Create a clean, professional profile image for a technology brand.

Visual direction
- Central subject: a simple, distinctive technology-inspired symbol.
- Style: minimal, precise, modern, and suitable for a professional brand.
- Composition: centered subject with strong visual recognition at small sizes.
- Background: uncluttered and high contrast against the main symbol.
- Lighting and finish: controlled, polished, with clear edges and restrained detail.

Technical requirements
- Square 1:1 composition.
- Keep important elements inside a safe central area for circular cropping.
- Avoid tiny text, unnecessary decorative elements, mockup scenes, watermarks, and unrelated logos.
- Do not add a company name or initials unless supplied separately.

Deliver one clear visual direction rather than a collage of alternatives.
```

## Example D: Existing prompt refinement

User request:
"Make this prompt better but do not change what it asks for: [paste prompt]."

Expected approach:
- Preserve the original objective, target audience, deliverables, and explicit constraints.
- Remove ambiguity, repeated wording, and contradictions.
- Add missing output structure only when it helps fulfil the original request.
- Do not add technologies, features, facts, or scope that the user did not request.
- Return the improved English prompt and a very brief summary of any material change, unless the user asks for prompt-only output.
