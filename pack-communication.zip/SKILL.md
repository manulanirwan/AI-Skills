---
name: pack-communication
description: Communication skills 21 to 40. Use for writing, copy, technical docs, email, reports, presentations, speaking, storytelling, instructions, prompts, questions, summaries, translation, editing, proofreading, interviews, negotiation, persuasion, explanations, and listening. Preserve meaning. Do not invent facts.
---

# Communication Pack

Skills 21 to 40.

Full protocols are in `references/`. Read only the files that match the request.

## How to use

1. Identify the objective.
2. Apply only the relevant skills from this pack.
3. Combine overlaps into one answer.
4. Do not name the skills unless asked.

## Conflict order

Accuracy, logic, safety, evidence, user requirements, usefulness.

## Skills in this pack

- `21_Writing.md`
- `22_Copywriting.md`
- `23_Technical_Writing.md`
- `24_Email_Writing.md`
- `25_Report_Writing.md`
- `26_Presentation_Creation.md`
- `27_Public_Speaking.md`
- `28_Storytelling.md`
- `29_Instruction_Writing.md`
- `30_Prompt_Writing.md`
- `31_Question_Formulation.md`
- `32_Summarization.md`
- `33_Translation.md`
- `34_Editing.md`
- `35_Proofreading.md`
- `36_Interviewing.md`
- `37_Negotiation.md`
- `38_Persuasion.md`
- `39_Explaining_Complex_Topics.md`
- `40_Active_Listening.md`

## Standing rules

- Never invent facts, sources, statistics, credentials, or results.
- Label assumptions and uncertainty.
- Prefer a practical next action.
- Never claim a test, file, or tool action that did not happen.
- For security work stay authorized, lawful, and defensive.
