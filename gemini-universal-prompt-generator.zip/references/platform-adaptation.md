# Platform Adaptation Notes

Use these notes as guidance, not as claims that every account has every feature. Check the platform and environment named by the user. If capabilities are uncertain, phrase tool use conditionally.

## Gemini

- Write clear instructions with the required context, intended result, constraints, and output format.
- For tasks using files, images, Google Drive, Workspace, or other connected sources, ask Gemini to use only the sources actually available in that chat or account.
- For research, request source verification and citations when browsing or source tools are available. Require an explicit limitation statement when they are not.
- For long multi-part tasks, divide work into ordered stages and ask for a progress summary at meaningful checkpoints.
- For reusable Gemini Skills, keep the skill's purpose and trigger description specific. The user can invoke a saved skill explicitly or allow automatic use when enabled.

## Claude

- Keep the role, task, context, constraints, and expected output explicit.
- For multi-step work, describe the intended process and decision points.
- For projects involving files or code, identify the files to inspect and require evidence before claiming a change or test succeeded.
- Do not assume that a Claude Skill, Project, connector, or computer-use capability is enabled unless the user confirms it.

## ChatGPT

- State whether the task needs browsing, file analysis, coding, image generation, or other tools, and require the model to use them only when available and suitable.
- For research, ask for citations close to claims and distinguish current facts from general knowledge.
- For file tasks, require the model to inspect the supplied files rather than infer unseen content.
- For deliverables, specify the desired file type, structure, and acceptance criteria.

## Grok

- State the task, context, constraints, and desired output directly.
- For current events or claims that may change, ask for up-to-date verification and source links when search is available.
- Do not assume that a particular Grok mode, tool, or custom bot capability is available in the user's interface.

## Coding agents and IDE assistants

- Specify repository, branch, language, framework, runtime versions, package manager, and deployment target when known.
- Require repository inspection before edits. Ask the agent to summarize architecture and identify relevant files first.
- Prefer small, scoped changes. Preserve existing patterns unless there is a clear reason to change them.
- Include acceptance criteria and relevant tests, lint, type checks, build steps, and security checks.
- Require exact reporting of commands run and their outcomes. No fabricated test success.
- Avoid destructive file, database, infrastructure, or deployment operations without explicit approval.

## Image and video generation tools

- Describe the subject, action, setting, composition, visual style, lighting, camera or framing, text requirements, output aspect ratio, and exclusions as needed.
- Keep essential subject identity and reference-image constraints explicit when supplied.
- Avoid contradictory instructions. Use a short negative-constraints section only for likely failure modes.
- For video, define duration, shot sequence, movement, transitions, audio, and continuity where relevant.

## Platform-neutral fallback

When the target is unknown, create a platform-neutral prompt. Do not mention platform-only features. Include a short note identifying any capability that may need to be adapted after the user selects a platform.
