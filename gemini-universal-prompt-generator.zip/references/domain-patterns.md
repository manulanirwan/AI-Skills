# Domain Prompt Patterns

Pick the pattern that fits the task. Combine patterns only when necessary.

## Research and fact-checking

Include the research question, scope, time period, geography, source quality requirements, comparison criteria, citation style, and expected report structure. Ask the AI to verify dates, separate facts from interpretations, flag conflicting evidence, and state research limitations. Do not instruct it to invent sources.

## Business planning

Include business idea, location, customer segment, problem, offer, available resources, starting budget, constraints, time horizon, and desired scale. Ask for assumptions, market validation steps, operating plan, risks, cost and revenue estimates with transparent calculations, and milestones. Label estimates and identify what needs local verification.

## Software development

Include user problem, user roles, features, non-functional requirements, stack, environment, integrations, data model, access controls, deployment target, and constraints when known. Ask for architecture, implementation sequence, acceptance criteria, tests, and security/privacy checks. For existing repositories, inspect before proposing or changing code.

## Cybersecurity and privacy

Include authorization, assets in scope, exclusions, test window, environment, rules of engagement, and reporting needs. Prefer defensive assessment, configuration review, safe proof-of-concept validation, remediation, monitoring, and incident response. Do not produce instructions for unauthorized compromise, credential theft, malware, or stealth.

## Writing and communication

Include audience, purpose, channel, tone, key facts, required call to action, length, and phrases or claims to avoid. Preserve the source meaning and do not add unsupported facts. For writing in a language other than English, distinguish the language of the deliverable from the language of the prompt itself.

## Learning and tutoring

Include learner level, subject, target outcome, prior knowledge, time available, and preferred learning format. Ask for explanations at the right level, worked examples, practice questions, feedback, and checks for understanding. Do not assume the learner wants the final answer when guided learning is requested.

## Data analysis and spreadsheets

Include the data source, field definitions, business question, expected calculations, units, treatment of missing values, and output format. Ask the AI to inspect the data first, document assumptions, validate calculations, and distinguish findings from causation. Never invent rows or values.

## Image creation

Include subject, number of subjects, action, setting, composition, style, colours if specified, lighting, details to preserve, text to render, aspect ratio, and negative constraints. Keep the prompt consistent and avoid adding unrequested elements.

## Video creation

Include topic, purpose, audience, duration, aspect ratio, scene order, camera movement, transitions, visual continuity, spoken words, sound, captions, and delivery format where relevant.

## Decision support

Include the decision, available options, goals, constraints, risk tolerance, evaluation criteria, and deadline. Ask for trade-offs, evidence, uncertainty, sensitivity to assumptions, and what further information would change the recommendation. Avoid false precision.
