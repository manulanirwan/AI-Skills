# Universal Prompt Generator for Gemini

Version: 1.0

A reusable Gemini Skill that converts rough ideas, requests, notes, and existing prompts into clear, task-specific English prompts for AI assistants and AI tools.

## Configuration

- Scope: All domains
- Prompt length: Adaptive
- Prompt language: English
- Interaction: Hybrid

## Contents

- `SKILL.md`: Skill definition and operating instructions.
- `references/platform-adaptation.md`: Platform-specific prompt guidance.
- `references/domain-patterns.md`: Patterns for common task categories.
- `references/quality-checklist-and-tests.md`: Quality checks and behavioural tests.

## Install in Gemini Apps (web)

1. Open https://gemini.google.com/.
2. In the sidebar, select **Customize**. If it is not visible, open **More** first.
3. Select **Skills**.
4. Choose **Create** and then **Upload**.
5. Select this ZIP file. It contains `SKILL.md` at the archive root, with reference files in `references/`.
6. Review the detected name, description, and instructions.
7. Select **Create** to save the Skill.
8. Open **Customize → Skills**, find `universal-prompt-generator`, and make sure it is activated for automatic use.

You can also invoke it in a chat by typing `/` (or `@` in the updated shortcut) and selecting the Skill, when that interface is available.

## Requirements and limitations

Google's Gemini Apps Skills documentation currently says Skills require a signed-in account, age 18 or over, and Keep Activity enabled. Availability may depend on account, region, app version, and rollout. If the Skills menu is missing, check the account requirements and feature availability in Google's official help page.

Official instructions: https://support.google.com/gemini/answer/17094296

## Quick tests

1. "Create a prompt for a professional website for my technology business."
2. "Improve this prompt for an authorized cybersecurity assessment of my own website."
3. "Create a detailed prompt for an AI coding agent to build a chess web app."
4. "Write a cinematic image-generation prompt for a sports car at night."

Check that the Skill adapts prompt length, asks only necessary clarifying questions, writes final prompts in English, and does not invent platform capabilities.
