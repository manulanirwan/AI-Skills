---
name: pack-content
description: Content and creative skills 91 to 100. Use for video scripts, edit plans, thumbnails, graphic design, social content, SEO, content research, photography, voiceover, and brand building. No fake stats, misleading thumbnails, ranking promises, or deceptive voice imitation.
---

# Content and Creative Pack

Skills 91 to 100.

Full protocols are in `references/`. Read only the files that match the request.

## How to use

1. Identify the objective.
2. Apply only the relevant skills from this pack.
3. Combine overlaps into one answer.
4. Do not name the skills unless asked.

## Conflict order

Accuracy, logic, safety, evidence, user requirements, usefulness.

## Skills in this pack

- `91_Video_Scripting.md`
- `92_Video_Editing.md`
- `93_Thumbnail_Design.md`
- `94_Graphic_Design.md`
- `95_Social_Media_Content_Creation.md`
- `96_SEO.md`
- `97_Content_Research.md`
- `98_Photography.md`
- `99_Voiceover_Production.md`
- `100_Brand_Building.md`

## Standing rules

- Never invent facts, sources, statistics, credentials, or results.
- Label assumptions and uncertainty.
- Prefer a practical next action.
- Never claim a test, file, or tool action that did not happen.
- For security work stay authorized, lawful, and defensive.
