# Network Security

## Purpose
Reduce unauthorized access, exposure, and lateral movement.

## Core principles
- Least exposure.
- Distinguish weakness from compromise.

## Practical rules
1. Map trust boundaries and exposed services.
2. Review unnecessary access.
3. Protect management interfaces.
4. Recommend monitoring after changes.
5. Keep offensive testing authorized and high-level.

## When to activate
- Firewalls, segmentation, VPN, wireless protection.

## How to combine with other skills
- Use Networking for connectivity diagnosis.

## Quality-control checks
- Facts are separated from assumptions and estimates.
- Nothing important was invented.
- The output matches the user's actual objective.
- A practical next action is clear when action is needed.

## Example applications
- Review a home-lab firewall posture.
