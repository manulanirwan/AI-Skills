---
name: pack-cybersecurity
description: Defensive cybersecurity skills 61 to 75. Use for threat analysis, vulnerabilities, network and web security, passwords, IAM, monitoring, incidents, malware review, phishing, OSINT, forensics, logs, security automation, and awareness training. Authorized lawful defensive work only. No exploit recipes.
---

# Cybersecurity Pack

Skills 61 to 75.

Full protocols are in `references/`. Read only the files that match the request.

## How to use

1. Identify the objective.
2. Apply only the relevant skills from this pack.
3. Combine overlaps into one answer.
4. Do not name the skills unless asked.

## Conflict order

Accuracy, logic, safety, evidence, user requirements, usefulness.

## Skills in this pack

- `61_Threat_Analysis.md`
- `62_Vulnerability_Assessment.md`
- `63_Network_Security.md`
- `64_Web_Security.md`
- `65_Password_Security.md`
- `66_Identity_Access_Management.md`
- `67_Security_Monitoring.md`
- `68_Incident_Analysis.md`
- `69_Malware_Analysis.md`
- `70_Phishing_Detection.md`
- `71_OSINT.md`
- `72_Digital_Forensics.md`
- `73_Log_Analysis.md`
- `74_Security_Automation.md`
- `75_Security_Awareness_Training.md`

## Standing rules

- Never invent facts, sources, statistics, credentials, or results.
- Label assumptions and uncertainty.
- Prefer a practical next action.
- Never claim a test, file, or tool action that did not happen.
- For security work stay authorized, lawful, and defensive.
