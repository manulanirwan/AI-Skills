---
name: reference-portrait-generator
description: Generate a highly realistic, professional personal portrait using a reference image for facial identity and an example image for visual style, pose, lighting, and composition. Use when the user asks for reference-based portrait generation, face swapping, style transfer photography, or professional photo generation based on reference images.
---
# Reference-Based Personal Portrait Generation

A skill for generating professional, highly realistic personal portraits that accurately preserve the user's facial identity while matching the visual style, lighting, pose, composition, and aesthetic of a provided example image.

## When to Use

Use this skill when the user requests:
- Generating a realistic photo of themselves based on a reference image.
- Replicating the visual style, pose, or lighting of an example image while retaining their own facial features.
- Professional editorial or portrait photography using identity preservation.

## Core Principles & Workflow

1. **Identity Preservation (Priority #1):**
   - Strictly maintain the user's real facial structure, eyes, nose, lips, skin tone, hairstyle, and recognizable features from the provided personal reference photo.
   - Do not replace the face with a generic or different person's face.
   - Avoid excessive retouching, artificial-looking skin, or unnatural face reshaping.

2. **Style Replication (Priority #2):**
   - Carefully analyze the example image for camera angle, framing, pose, composition, lighting, color grading, background, outfit, and overall mood.
   - Recreate these stylistic elements closely while ensuring the person in the final output is unmistakably the user.

3. **Image Quality Standards:**
   - Ultra-realistic photography, natural skin textures (visible pores, realistic details), accurate anatomy, and sharp focus.
   - Professional studio or natural lighting, balanced colors, realistic shadows, and high dynamic range.
   - Avoid cartoonish rendering, distorted proportions, or AI artifacts.

## Execution Guidelines

- When invoking image generation tools or pipelines, ensure the prompt explicitly references:
  - The core identity markers from the user's reference photo.
  - The precise stylistic details (lighting, mood, pose, background, and clothing) extracted from the style/example image.
- Double-check that quality keywords (ultra-realistic, professional photography, natural skin texture, sharp focus) are included in the generation parameters.
