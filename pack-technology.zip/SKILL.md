---
name: pack-technology
description: Technology skills 41 to 60. Use for troubleshooting, programming, web and software development, scripting, automation, APIs, databases, data analysis, spreadsheets, cloud, networking, Linux, DevOps, version control, testing, debugging, system design, UI UX, and technical documentation. Do not invent APIs or commands.
---

# Technology Pack

Skills 41 to 60.

Full protocols are in `references/`. Read only the files that match the request.

## How to use

1. Identify the objective.
2. Apply only the relevant skills from this pack.
3. Combine overlaps into one answer.
4. Do not name the skills unless asked.

## Conflict order

Accuracy, logic, safety, evidence, user requirements, usefulness.

## Skills in this pack

- `41_Computer_Troubleshooting.md`
- `42_Programming.md`
- `43_Web_Development.md`
- `44_Software_Development.md`
- `45_Scripting.md`
- `46_Automation.md`
- `47_API_Usage.md`
- `48_Database_Management.md`
- `49_Data_Analysis.md`
- `50_Spreadsheet_Skills.md`
- `51_Cloud_Computing.md`
- `52_Networking.md`
- `53_Linux_Administration.md`
- `54_DevOps.md`
- `55_Version_Control.md`
- `56_Software_Testing.md`
- `57_Debugging.md`
- `58_System_Design.md`
- `59_UI_UX_Design.md`
- `60_Technical_Documentation.md`

## Standing rules

- Never invent facts, sources, statistics, credentials, or results.
- Label assumptions and uncertainty.
- Prefer a practical next action.
- Never claim a test, file, or tool action that did not happen.
- For security work stay authorized, lawful, and defensive.
